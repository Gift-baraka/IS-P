function generateRecommendation() {
  const moisture = document.getElementById('moisture')?.value;
  const temperature = document.getElementById('temperature')?.value;
  const output = document.getElementById('recommendation');
  if (!output) return;

  let message = "";
  if (moisture === "" || temperature === "") {
    message = "Please enter all required data.";
  } else if (moisture < 50) {
    message = "Irrigation required today!";
  } else {
    message = "No irrigation needed today.";
  }

  output.textContent = message;
  output.style.display = 'block';
}

function filterHistory() {
  alert("Filter functionality can be implemented with backend or JS filtering.");
}

function resetHistory() {
  document.getElementById('filterCrop').value = "";
  document.getElementById('startDate').value = "";
  document.getElementById('endDate').value = "";
}
